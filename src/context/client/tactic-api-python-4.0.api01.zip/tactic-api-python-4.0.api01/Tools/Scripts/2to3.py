#!/usr/bin/env python
from lib2to3.main import main
import sys
import os

sys.exit(main("lib2to3.fixes"))
