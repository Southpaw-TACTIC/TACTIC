############################################################
#
#    Copyright (c) 2012, Southpaw Technology
#                        All Rights Reserved
#
#    PROPRIETARY INFORMATION.  This software is proprietary to
#    Southpaw Technology, and is not to be reproduced, transmitted,
#    or disclosed in any way without written permission.
#
#
__all__ = ['BaseCmd', 'DelegateCmd']

from subversion import *
from perforce import *

import os, sys, traceback
import simplejson as json
import pprint


from subversion import Subversion
from perforce import PerforceImpl

class BaseCmd():

    def __init__(my, **kwargs):
        my.kwargs = kwargs
        my.ret_val = {}

        # the the scm user and password
        user = my.kwargs.get("user")
        password = my.kwargs.get("password")
        root = my.kwargs.get("root")
        sync_dir = my.kwargs.get("sync_dir")
        branch = my.kwargs.get("branch")

        sync_path = my.kwargs.get("sync_path")

        #my.scm = Subversion(user=user, password=password)
        my.scm = PerforceImpl(**kwargs)
        my.scm.set_root(root)
        my.scm.set_branch(branch)
        my.scm.set_sync_dir(sync_dir)


    def get_log(my):
        return my.scm.get_log()


class DelegateCmd(BaseCmd):
    def execute(my):
        method = my.kwargs.get("method")
        args = my.kwargs.get("args")
        ret_val = eval("my.scm.%s(*args)" % method)
        return {
           "value": ret_val,
           "error": None,
           "log": my.scm.get_log()
        }






def main():
    tactic_data = "C:/ProgramData/Southpaw/Tactic"
    base = "%s/temp/output" % tactic_data

    cmd = None

    try:

        #from tactic_client_lib import TacticServerStub
        #server = TacticServerStub.get()
        #server.set_server("192.168.153.238")
        #ticket = server.get_ticket("admin", "tactic")
        #server.set_ticket(ticket)
        #server.ping()

        if not os.path.exists(base):
            os.makedirs(base)


        f = open("%s/kwargs.json" % base, 'r')
        kwargs_json = f.read()
        f.close()

        # FIXME: HARD CODED
        from tactic_client_lib import scm


        kwargs = json.loads(kwargs_json)
        kwargs2 = {}
        for key, value in kwargs.items():
            kwargs2[key.encode("UTF8")] = value

        class_name = kwargs.get("class_name")
        cmd = eval("%s(**kwargs2)" % class_name)
        ret_val = cmd.execute()

        ret_val['status'] = 'OK'
        ret_val_json = json.dumps(ret_val)

        f = open("%s/output.json" % base, 'w')
        f.write(ret_val_json)
        f.close()

        f = open("%s/pretty_output.json" % base, 'w')
        pp = pprint.PrettyPrinter(indent=4, stream=f)
        pp.pprint(ret_val)
        f.close()


    except Exception, e:
        error = str(e)
        print error
        f = open("%s/output.json" % base, 'w')


        tb = sys.exc_info()[2]
        stacktrace = traceback.format_tb(tb)
        stacktrace_str = "".join(stacktrace)

        ret_val = {
            "status": "error" ,
            "msg": "%s" % e,
            "stack_trace": stacktrace_str
        }

        if cmd:
            ret_val['log'] = cmd.get_log()

        ret_val_json = json.dumps(ret_val)
        f.write(ret_val_json);
        f.close()

        f = open("%s/pretty_output.json" % base, 'w')
        pp = pprint.PrettyPrinter(indent=4, stream=f)
        pp.pprint(ret_val)
        f.close()



if __name__ == '__main__':
    main()



