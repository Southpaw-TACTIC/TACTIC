#!C:\Data\Southpaw\TacticStandalone\tactic-3.7-python-2.6-complete\python\python.exe
# EASY-INSTALL-SCRIPT: 'PySide==1.0.7qt474','pyside_postinstall.py'
__requires__ = 'PySide==1.0.7qt474'
import pkg_resources
pkg_resources.run_script('PySide==1.0.7qt474', 'pyside_postinstall.py')
