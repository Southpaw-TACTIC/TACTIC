#!C:\Data\Southpaw\TacticStandalone\tactic-3.7-python-2.6-complete\python\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'PySide==1.0.7qt474','console_scripts','pyside-uic'
__requires__ = 'PySide==1.0.7qt474'
import sys
from pkg_resources import load_entry_point

sys.exit(
   load_entry_point('PySide==1.0.7qt474', 'console_scripts', 'pyside-uic')()
)
