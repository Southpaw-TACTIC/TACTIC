#!C:\Data\Southpaw\Standalone\Tactic-3.7\python\python.exe
# EASY-INSTALL-SCRIPT: 'PIL==1.1.7','pilfont.py'
__requires__ = 'PIL==1.1.7'
import pkg_resources
pkg_resources.run_script('PIL==1.1.7', 'pilfont.py')
